import hashlib
import json
import os
from pathlib import Path
import pwd
import grp
import sqlite3
import subprocess
import time

BASE = Path('/var/tmp/rss-watch-acceptance-20260916')
SOURCE = BASE / 'rss_watch-0.1.0'
TARGET = Path('/opt/rss-watch')
CONFIG = Path('/etc/rss-watch/config.toml')
DATA = Path('/var/lib/rss-watch')
UNIT = Path('/etc/systemd/system/rss-watch.service')
DROP = Path('/etc/systemd/system/rss-watch.service.d/99-acceptance-refuse-stop.conf')
results = []

def run(args, expected=0, cwd=None):
    p = subprocess.run([str(a) for a in args], cwd=cwd, text=True,
                       stdin=subprocess.DEVNULL, capture_output=True, timeout=180)
    with (BASE / 'acceptance-commands.log').open('a') as f:
        f.write(f'COMMAND {args}\nEXIT {p.returncode}\n{p.stdout}\n{p.stderr}\n')
    assert p.returncode == expected, (args, p.returncode, p.stdout[-3000:], p.stderr[-3000:])
    return p.stdout

def passed(name):
    results.append(name)
    (BASE / 'acceptance-results.json').write_text(json.dumps(results, indent=2))
    print('PASS:', name, flush=True)

def active():
    run(['systemctl', 'is-active', '--quiet', 'rss-watch.service'])

def fingerprint(root):
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}

def uninstall(*flags, expected=0, inside=False):
    script = TARGET / 'current/deploy/uninstall.sh' if inside else SOURCE / 'deploy/uninstall.sh'
    return run([script, *flags], expected, TARGET / 'current' if inside else SOURCE)

active()
run([TARGET / 'current/deploy/check.sh'])
passed('real systemd first install, enabled, heartbeat, sandbox and health check')

run(['sudo', '-u', 'rss-watch', TARGET / 'current/.venv/bin/python', '-c',
     'from pathlib import Path; from rss_watch.config import load_config; '
     'from rss_watch.service import Service; '
     's=Service(load_config(Path("/etc/rss-watch/config.toml"))); '
     's.bot_save("acceptance-only", "https://open.feishu.cn/open-apis/bot/v2/hook/acceptance-not-real", "dummy"); '
     's.backup(Path("/var/lib/rss-watch/backups/acceptance"))'])
credentials = fingerprint(Path('/etc/rss-watch/credentials'))
backup = fingerprint(DATA / 'backups/acceptance')
uid = pwd.getpwnam('rss-watch').pw_uid
pid = run(['systemctl', 'show', 'rss-watch', '-p', 'MainPID', '--value'])
for flags in [('--dry-run',), ('--purge', '--dry-run')]:
    uninstall(*flags, inside=True)
    assert pid == run(['systemctl', 'show', 'rss-watch', '-p', 'MainPID', '--value'])
    assert fingerprint(Path('/etc/rss-watch/credentials')) == credentials
    assert fingerprint(DATA / 'backups/acceptance') == backup
passed('dry-run keeps actual service PID, credentials and backups')

uninstall('--purge', expected=1)
active()
assert TARGET.exists() and CONFIG.exists()
passed('noninteractive purge without explicit yes rejected before changes')

DROP.parent.mkdir(exist_ok=True)
DROP.write_text('[Unit]\nRefuseManualStop=yes\n')
try:
    run(['systemctl', 'daemon-reload'])
    uninstall(expected=1)
    active()
    assert UNIT.exists() and TARGET.exists() and CONFIG.exists()
    passed('real systemd stop refusal aborts without deleting files')
finally:
    DROP.unlink(missing_ok=True)
    DROP.parent.rmdir()
    run(['systemctl', 'daemon-reload'])

run([TARGET / 'current/deploy/install.sh'], cwd=TARGET / 'current')
active()
assert len(list((TARGET / 'releases').iterdir())) >= 2
assert not (TARGET / 'current/releases').exists()
passed('upgrade from inside installation, real uv, releases and service restart')

uninstall(inside=True)
assert not TARGET.exists() and not UNIT.exists()
assert CONFIG.exists() and DATA.exists()
assert pwd.getpwnam('rss-watch').pw_uid == uid
assert credentials == fingerprint(Path('/etc/rss-watch/credentials'))
assert backup == fingerprint(DATA / 'backups/acceptance')
with sqlite3.connect(DATA / 'rss-watch.sqlite3') as db:
    assert db.execute('select count(*) from bots').fetchone()[0] == 1
passed('default uninstall inside installation preserves database, credentials, backups and UID')
uninstall()
passed('repeated default uninstall with missing systemd unit succeeds')

run([SOURCE / 'deploy/install.sh'], cwd=SOURCE)
active()
run([TARGET / 'current/deploy/check.sh'])
assert pwd.getpwnam('rss-watch').pw_uid == uid
record = json.loads(Path('/etc/rss-watch/install-receipt.json').read_text())
assert record['user']['created'] and record['group']['created']
passed('reinstall preserves data, UID and installer account ownership record')

uninstall('--purge', '--yes', inside=True)
for path in [TARGET, CONFIG, DATA, UNIT, Path('/etc/rss-watch/credentials')]:
    assert not path.exists(), path
for lookup in [pwd.getpwnam, grp.getgrnam]:
    try:
        lookup('rss-watch')
        raise AssertionError('account/group remains')
    except KeyError:
        pass
passed('purge inside installation removes service, data, backups and installer-created account/group')
uninstall('--purge', '--yes')
passed('repeated purge on real systemd succeeds')
print('ALL REAL SYSTEMD ACCEPTANCE CHECKS PASSED', flush=True)
