import os, pathlib, shutil, subprocess, pwd, grp, time
P=pathlib.Path
source=P.cwd()
target=P('/opt/rss-watch')
data=P('/var/lib/rss-watch-legacy-test')
config=P('/etc/rss-watch/config.toml')
unit=P('/etc/systemd/system/rss-watch.service')
def run(args,cwd=None):
    subprocess.run([str(x) for x in args],cwd=cwd,check=True,timeout=120)
assert not target.exists() and not config.exists() and not data.exists() and not unit.exists()
run(['useradd','--system','--user-group','--home-dir',data,'--shell','/usr/sbin/nologin','rss-watch'])
uid=pwd.getpwnam('rss-watch').pw_uid
shutil.copytree(source,target,ignore=shutil.ignore_patterns('.venv','__pycache__','.pytest_cache','.ruff_cache'))
run(['/opt/rss-watch-test-tools/uv','sync','--locked','--no-dev','--python',os.environ['RSS_WATCH_PYTHON_BIN']],cwd=target)
run(['install','-d','-m','0700','-o','rss-watch','-g','rss-watch',config.parent,config.parent/'credentials',data])
config.write_text(f'data_dir="{data}"\ncredentials_dir="/etc/rss-watch/credentials"\n')
unit.write_text((source/'deploy/rss-watch.service').read_text().replace('/opt/rss-watch/current','/opt/rss-watch').replace('/var/lib/rss-watch',str(data)))
run(['systemctl','daemon-reload'])
run(['systemctl','enable','--now','rss-watch'])
time.sleep(2)
run(['systemctl','is-active','--quiet','rss-watch'])
run(['sudo','-u','rss-watch',target/'.venv/bin/rss-watch','backup',data/'backups/legacy-test'])
assert not (config.parent/'install-receipt.json').exists()
run([target/'deploy/uninstall.sh','--purge','--yes'],cwd=target)
assert not target.exists() and not config.exists() and not data.exists() and not unit.exists()
assert pwd.getpwnam('rss-watch').pw_uid==uid
print('PASS: real legacy single-directory in-place purge, custom data path, unrecorded account preserved',flush=True)
run(['userdel','rss-watch'])
try:
    grp.getgrnam('rss-watch')
except KeyError:
    pass
else:
    run(['groupdel','rss-watch'])
print('PASS: manually created acceptance account cleaned up',flush=True)
